# KTMCHAT V5 — Premium Futuristic Edition

Kotlin + Jetpack Compose Android project. Package: `com.ktmchat.app`.

## What is included

- Futuristic dark interface with violet/cyan accents
- Chat list, searchable demo conversations and local message sending
- Stories screen and story list preview
- Calls history screen and audio/video call entry-point UI
- Communities screen
- Profile screen, appearance toggle and admin dashboard preview
- GitHub Actions workflow that builds a debug APK and publishes it as a downloadable workflow artifact

## Important functionality status

This V5 starter is a **buildable front-end prototype**. Chat messages are held in app memory and are not synchronized between phones. Story creation, media upload, authentication, push notifications, real voice/video calls, admin authorization, cloud moderation and end-to-end encryption are not connected to production services yet. The admin dashboard is a demo and must not be treated as secure access control.

Before public release, add and test:
- Firebase Authentication and Firestore/Storage (or another backend)
- Server-side authorization and security rules
- Firebase Cloud Messaging for push notifications
- WebRTC or a calling provider for real calls
- A reviewed end-to-end encryption protocol and key management
- Real media picker/camera flows, moderation and privacy controls

## Build requirements

- Android Studio or a Linux CI runner
- JDK 17
- Android SDK platform 35
- Gradle 8.11.1
- Android Gradle Plugin 8.9.2

## Build with Android phone only (GitHub Actions)

1. Create a GitHub account at https://github.com/signup.
2. In GitHub, create a new **public** repository named `KTMCHAT` (public is easiest for a free GitHub Actions workflow).
3. Upload the contents of this ZIP into the repository root. Upload the files/folders inside `KTMCHAT_V5`, not the outer folder itself. Make sure `.github/workflows/android.yml` is included.
4. Open the repository's **Actions** tab. If asked, enable workflows.
5. Select **Build KTMCHAT APK** and tap **Run workflow**. If the workflow has already run after upload, open its latest run instead.
6. Wait for the green check mark.
7. Open the completed workflow run and find **Artifacts** near the bottom.
8. Download `KTMCHAT-debug-apk`. GitHub downloads this artifact as a ZIP.
9. Extract that ZIP on your phone. It contains `app-debug.apk`.
10. Tap `app-debug.apk` and follow Android's install prompt. If asked, allow your browser or file manager to install unknown apps. Only install APKs you built and trust.

## Build locally

Open the project in Android Studio and run:

```bash
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## App identity

- App name: KTMCHAT
- Version: 5.0
- Application ID: `com.ktmchat.app`
