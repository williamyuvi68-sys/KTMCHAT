package com.ktmchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090914)
private val Panel = Color(0xFF151528)
private val Panel2 = Color(0xFF1D1B35)
private val Violet = Color(0xFF9B72FF)
private val Cyan = Color(0xFF54D6E8)
private val Muted = Color(0xFF9996B5)
private val White = Color(0xFFF7F4FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KtmChatApp() }
    }
}

private data class ChatItem(val name: String, val message: String, val time: String, val unread: Int, val color: Color)
private data class StoryItem(val name: String, val color: Color, val isNew: Boolean)

@Composable
fun KtmChatApp() {
    var tab by remember { mutableStateOf("Chats") }
    var selectedChat by remember { mutableStateOf<ChatItem?>(null) }
    var search by remember { mutableStateOf("") }
    var darkMode by remember { mutableStateOf(true) }
    var showAdmin by remember { mutableStateOf(false) }

    val chats = remember {
        listOf(
            ChatItem("Aarav Sharma", "That sounds awesome! 🔥", "09:41", 2, Color(0xFF7C65E8)),
            ChatItem("Sanjay • KTM Crew", "You: See you tonight", "08:56", 5, Color(0xFF3B9FAE)),
            ChatItem("Maya K.", "Sent a photo", "Yesterday", 0, Color(0xFFE18BBA)),
            ChatItem("Design Squad", "Ritika: New concept uploaded", "Yesterday", 3, Color(0xFFB28A52)),
            ChatItem("Nisha Thapa", "Voice message · 0:18", "Mon", 0, Color(0xFF5B9D79)),
            ChatItem("KTM Developers", "Build is ready to test", "Sun", 0, Color(0xFF7186D9))
        )
    }
    val stories = remember {
        listOf(
            StoryItem("Your story", Violet, false),
            StoryItem("Aarav", Color(0xFF3F9BB0), true),
            StoryItem("Maya", Color(0xFFCF75A6), true),
            StoryItem("Sanjay", Color(0xFFB38A50), true),
            StoryItem("Nisha", Color(0xFF659C7B), false)
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Violet, secondary = Cyan,
        onBackground = White, onSurface = White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            if (selectedChat != null) {
                ChatDetail(selectedChat!!, onBack = { selectedChat = null })
            } else if (showAdmin) {
                AdminScreen(onBack = { showAdmin = false })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header(onAdmin = { showAdmin = true })
                    when (tab) {
                        "Chats" -> ChatsScreen(chats, stories, search, { search = it }, { selectedChat = it })
                        "Stories" -> StoriesScreen(stories)
                        "Calls" -> CallsScreen()
                        "Communities" -> CommunitiesScreen()
                        else -> ProfileScreen(darkMode, { darkMode = it }, { showAdmin = true })
                    }
                    Spacer(Modifier.weight(1f))
                    BottomBar(tab, { tab = it })
                }
            }
        }
    }
}

@Composable
private fun Header(onAdmin: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Forum, null, tint = Color.White) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("KTMCHAT", fontSize = 21.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = 1.4.sp)
            Text("YOUR WORLD. YOUR PEOPLE.", fontSize = 9.sp, color = Cyan, letterSpacing = 1.5.sp)
        }
        IconButton(onClick = onAdmin) { Icon(Icons.Default.Dashboard, "Admin dashboard", tint = Muted) }
        Icon(Icons.Default.MoreVert, null, tint = Muted)
    }
}

@Composable
private fun ChatsScreen(
    chats: List<ChatItem>, stories: List<StoryItem>, search: String,
    onSearch: (String) -> Unit, onOpen: (ChatItem) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Messages", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
        Text("Stay close to your people", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search conversations", color = Muted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            singleLine = true, shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Violet, unfocusedBorderColor = Panel2,
                focusedTextColor = White, unfocusedTextColor = White,
                cursorColor = Cyan, focusedContainerColor = Panel, unfocusedContainerColor = Panel
            )
        )
        Spacer(Modifier.height(18.dp))
        Text("STORIES", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            stories.forEach { StoryBubble(it) }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Recent chats", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("See all", color = Cyan, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats.filter { it.name.contains(search, true) || it.message.contains(search, true) }) { chat ->
                ChatRow(chat) { onOpen(chat) }
            }
        }
    }
}

@Composable
private fun StoryBubble(story: StoryItem) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(62.dp)) {
        Box(
            Modifier.size(54.dp).background(
                Brush.linearGradient(if (story.isNew) listOf(Cyan, Violet) else listOf(Panel2, Panel2)),
                CircleShape
            ).padding(3.dp).background(Bg, CircleShape).padding(3.dp)
                .background(story.color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(story.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(5.dp))
        Text(story.name, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ChatRow(chat: ChatItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).background(chat.color, CircleShape), contentAlignment = Alignment.Center) {
            Text(chat.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(chat.message, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, color = Muted, fontSize = 10.sp)
            if (chat.unread > 0) {
                Spacer(Modifier.height(5.dp))
                Box(Modifier.background(Violet, CircleShape).padding(horizontal = 7.dp, vertical = 3.dp)) {
                    Text(chat.unread.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ChatDetail(chat: ChatItem, onBack: () -> Unit) {
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Hey! How's everything?", "All good. Working on KTMCHAT V5.", "That sounds awesome! 🔥")) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = White) }
            Box(Modifier.size(38.dp).background(chat.color, CircleShape), contentAlignment = Alignment.Center) {
                Text(chat.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.name, color = White, fontWeight = FontWeight.SemiBold)
                Text("online • demo conversation", color = Cyan, fontSize = 10.sp)
            }
            IconButton(onClick = { }) { Icon(Icons.Default.Call, "Audio call", tint = Cyan) }
            IconButton(onClick = { }) { Icon(Icons.Default.Videocam, "Video call", tint = Violet) }
        }
        HorizontalDivider(color = Panel2)
        Text("TODAY", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(msg, color = White, modifier = Modifier.background(Panel2, RoundedCornerShape(16.dp)).padding(12.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AddCircle, null, tint = Violet, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Message...", color = Muted) }, singleLine = true,
                shape = RoundedCornerShape(22.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Violet, unfocusedBorderColor = Panel2,
                    focusedTextColor = White, unfocusedTextColor = White,
                    focusedContainerColor = Panel, unfocusedContainerColor = Panel
                )
            )
            IconButton(onClick = {
                if (draft.isNotBlank()) { messages = messages + draft.trim(); draft = "" }
            }) { Icon(Icons.Default.Send, "Send", tint = Cyan) }
        }
    }
}

@Composable
private fun StoriesScreen(stories: List<StoryItem>) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Stories", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
        Text("Moments disappear after 24 hours", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        stories.forEach { story ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(story.color, CircleShape), contentAlignment = Alignment.Center) {
                    Text(story.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(story.name, color = White, fontWeight = FontWeight.SemiBold)
                    Text(if (story.isNew) "New story available" else "Tap to add a moment", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
        Button(onClick = { }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Create a story")
        }
    }
}

@Composable
private fun CallsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Calls", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
        Text("Your recent connections", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        listOf("Aarav Sharma" to "Today, 09:12 · Outgoing", "Maya K." to "Yesterday · Missed call", "KTM Crew" to "Monday · Group call").forEach { (name, detail) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Call, null, tint = Cyan) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = White, fontWeight = FontWeight.SemiBold)
                    Text(detail, color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = { }) { Icon(Icons.Default.Call, "Call", tint = Violet) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Calling UI preview only. Connect a calling provider such as WebRTC before real calls.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CommunitiesScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Communities", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
        Text("Find your people and build together", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        listOf("KTM Creators" to "1.2k members", "Android Builders" to "846 members", "Kathmandu Hangouts" to "2.4k members").forEachIndexed { index, item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(listOf(Violet, Cyan, Color(0xFFCB7DA8))[index], RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Groups, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.first, color = White, fontWeight = FontWeight.SemiBold)
                    Text(item.second, color = Muted, fontSize = 11.sp)
                }
                Text("JOIN", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ProfileScreen(darkMode: Boolean, onDarkMode: (Boolean) -> Unit, onAdmin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("My profile", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(82.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), CircleShape), contentAlignment = Alignment.Center) {
                Text("K", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(10.dp))
            Text("KTMCHAT User", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("Welcome to your community", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text("Edit profile", color = Cyan, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { })
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DarkMode, null, tint = Violet)
            Spacer(Modifier.width(12.dp))
            Text("Dark appearance", color = White, modifier = Modifier.weight(1f))
            Switch(checked = darkMode, onCheckedChange = onDarkMode)
        }
        Spacer(Modifier.height(8.dp))
        ProfileAction(Icons.Default.AdminPanelSettings, "Admin dashboard", onAdmin)
        ProfileAction(Icons.Default.Security, "Privacy and security") { }
        ProfileAction(Icons.Default.Notifications, "Notifications") { }
        ProfileAction(Icons.Default.Help, "Help and support") { }
    }
}

@Composable
private fun ProfileAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Cyan)
        Spacer(Modifier.width(12.dp))
        Text(label, color = White, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun AdminScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = White) }
            Text("Admin dashboard", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text("Local demo dashboard · not secured for production", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AdminStat("Users", "1,284")
            AdminStat("Messages", "8.6k")
            AdminStat("Reports", "12")
        }
        Spacer(Modifier.height(18.dp))
        Text("Moderation tools", color = White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        listOf("Review user reports", "Manage members", "Community settings", "App activity").forEach {
            ProfileAction(Icons.Default.AdminPanelSettings, it) { }
        }
    }
}

@Composable
private fun RowScope.AdminStat(label: String, value: String) {
    Column(Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
        Text(value, color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    val items = listOf(
        Triple("Chats", Icons.Default.Chat, "Chats"),
        Triple("Stories", Icons.Default.AutoAwesome, "Stories"),
        Triple("Calls", Icons.Default.Call, "Calls"),
        Triple("Communities", Icons.Default.Groups, "Groups"),
        Triple("Profile", Icons.Default.Person, "Profile")
    )
    Row(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        items.forEach { (label, icon, _) ->
            val active = selected == label
            Column(Modifier.clickable { onSelect(label) }.padding(horizontal = 7.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = if (active) Cyan else Muted, modifier = Modifier.size(22.dp))
                Text(label, color = if (active) Cyan else Muted, fontSize = 9.sp)
            }
        }
    }
}
